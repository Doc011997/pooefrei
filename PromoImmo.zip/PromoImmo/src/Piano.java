public class Piano extends InstrumentACorde{

    public final static int nbreDeTouche = 88;


    public Piano(String nom, int prixAchat, int prixVente, int longueur, int largeur) {
        super(nom, prixAchat, prixVente, longueur, largeur);
    }
}
