public class Guitare extends InstrumentACorde {
    public Guitare(int longueur, int largeur) {
        super(longueur, largeur);
    }
}
