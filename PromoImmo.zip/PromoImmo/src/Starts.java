public enum Starts {

    QUATRE, CINQ


}
