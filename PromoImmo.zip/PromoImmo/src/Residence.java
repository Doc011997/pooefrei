public class Residence {
}
