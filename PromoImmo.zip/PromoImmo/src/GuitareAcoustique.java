public class GuitareAcoustique extends Guitare{

    private int tirant;
}
