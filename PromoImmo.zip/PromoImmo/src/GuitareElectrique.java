public class GuitareElectrique extends Guitare {


    private int amplificateur;
    private String pedalesSonore;

}
