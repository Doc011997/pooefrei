public class Magasin extends Batiment {
    public Magasin(String adresse, int surface, String proprio) {
        super(adresse, surface);
    }




}
